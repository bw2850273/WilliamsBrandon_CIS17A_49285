/* 
 * File:   main.cpp
 * Author: Brandon Williams
 * Hello World Assignment
 * Created on August 24, 2020, 6:44 PM
 * Purpose: To test if I am able to make a functioning program with NetBeans
 */

// System Libraries
#include <iostream> //Input/Output Library
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes

//Execution Begins Here

int main() 
{
    //Output to console
    cout << "Hello World";
    return 0;
}

//Function Definitions - None for this assignment