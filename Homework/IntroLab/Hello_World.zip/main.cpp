/* 
 * File:   main.cpp
 * Author: Brandon Williams
 * Hello World Assignment
 * Created on August 24, 2020, 6:44 PM
 * Purpose: To test if I am able to make a functioning program with NetBeans
 */

// System Libraries
#include <iostream> //Input/Output Library
using namespace std;

int main() 
{
    //Output to console
    cout << "Hello World";
    return 0;
}

